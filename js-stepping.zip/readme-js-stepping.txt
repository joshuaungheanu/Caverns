Readme for JS Stepping
Time-stamp: <2019-11-03 17:27:56 Chuck Siska>
------------------------------------------------------------
For CPSC-335, Project #2.

Files included: 
 o- readme-js-stepping.txt // This file.
 o- js-stepping.html // The HTML which has the Timer mechanism.
 o- js-stepping.js // Which has an example logging mechanism, optional.

To Run

  Open the .zip into a folder.  Drag/drop the .html file into a browser.

Summary

  There are several ways to do stepping in JS.  Using setInterval and
  clearInterval in conjunction with window.onload is perhaps the
  simplest.

  First, you assign an unnamed (AKA a "lambda"), function to
  window.onload (CF line 23 of html).  (Yes, you assign a function to an
  object's slot variable.)  This is your "load-once" function.  It will
  only run once when the HTML window is loaded.

  Second, inside this first unnamed function, you will create a timer-ID
  variable (CF timerx at line 28 in HTML) by calling setInterval().  You
  need to store the result of the setInterval call, this timer-ID, for
  use as an argument to clearInterval.

  Third, setInterval takes two arguments: the first argument is another
  unnamed ("lambda") function definition, your every-step function,
  inside of which you will call your display update function.  Your
  update function will do all the computations needed to update the
  display once (and probably including updating your internal program
  state, too, for next time.)  Your unnamed every-step function will run
  after each timer waiting period.

  The second setInterval argument is the amount of time (in
  milliseconds) that the timer must wait before running the unnamed
  every-step function again.  (NB, this is the minimum time to wait, but
  the browser and window system can cause a longer delay if they like --
  which you do not have to worry about for grading purposes.)

  Fourth, also inside this unnamed every-step function, you will
  eventually call clearInterval() with one argument, which is the timer
  ID that the setInterval call created and which you carefully stored in
  a variable, as described above.  We've used a Stop-count variable
  ("stop_cnt") and a "loop index" variable ("ix") to keep track of how
  many times the timer has run the unnamed every-step function.

  Addtionally, unrelated to the stepping mechanism, we've created a
  state object, a state-to-string function, and a logging function, so
  as to show the guts of the state object for each step of a run.  It is
  rather clunky, but you should get the idea.  We just dump a state
  description string into the upper-left of the display canvas.  We call
  it twice, once in black to erase the prior string and then in white to
  display the new string -- normal "brute force ugly".

  The tiny application just draws some small colored disks on the
  display canvas in a semi-random fashion, and then stops.

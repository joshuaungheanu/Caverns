
function state_string( rstate )
{
    let ss = "(S"
        + " cx" + rstate.center_x.toString( )
        + " cy" + rstate.center_y.toString( )
        + " x" + rstate.x.toString( )
        + " y" + rstate.y.toString( )
        + " clr=" + rstate.color.toString(16).toUpperCase( )
        + " di" + rstate.diam.toString( )
        + " radp=" + rstate.rad_pix.toString( )
        + " thed=" + rstate.thet_deg.toString( )
        // + " radpd=" + rstate.rad_pix_del.toString( )
        // + " thedd=" + rstate.thet_deg_del.toString( )
        + ")";
    return ss;
}

function log( rctx, rtext, rcolor ) 
{
    rctx.save( );
    rtext += " " + state_string( state );
    let fill = rcolor;
    let font = "12px Arial";
    rctx.fillStyle = fill;
    rctx.font = font;
    rctx.fillText( rtext, 2, 12);
    rctx.restore( );
}

function draw_rect( rctx, rstroke, rfill, rx, ry, rw ,rh ) 
{
    rstroke = rstroke || 'lightgrey';
    rfill = rfill || 'dimgrey';
    rx = rx || 0;
    ry = ry || 0;
    rctx.save( );
    rctx.strokeStyle = rstroke;
    rctx.fillStyle = rfill;
    rctx.lineWidth = 1;
    rctx.fillRect( rx, ry, rw, rh );
    rctx.stroke( );
    rctx.restore( );
}

function udpate_state( rstate )
{
    // Update Offset.
    rstate.rad_pix += Math.floor( rstate.rad_pix_del * 3 * Math.random());
    rstate.thet_deg += Math.floor( rstate.thet_deg_del * 3 * Math.random());
    rstate.thet_deg = rstate.thet_deg % 360;
    let radp = rstate.rad_pix;
    let thet_radians = rstate.thet_deg * (Math.PI / 360);
    // Update Disk loc.
    let offx = radp * Math.cos( thet_radians );
    let offy = radp * Math.sin( thet_radians );
    let absx = offx + rstate.center_x;
    let absy = offy + rstate.center_y;
    rstate.x = Math.floor( absx ) % 800;
    rstate.y = Math.floor( absy ) % 800;
    // Update Color.
    rstate.color = (rstate.color + rstate.color_del) % 0x8FFFFF;
}

// Draw state disk.
function draw_disk( rctx, rstate )
{    
    rctx.save( );
    rctx.beginPath( );
    rctx.arc( rstate.x, rstate.y, rstate.diam/2, 0, 2 * Math.PI );
    rctx.closePath();
    rctx.strokeStyle = ((2 * rstate.color) % 0x8FFFFF).toString(16);
    rctx.lineWidth = 0.5;
    rctx.fillStyle = "#" + rstate.color.toString(16);
    rctx.fill( );
    rctx.stroke( );
    rctx.restore( );
}

function act( rctx, rstate )
{   
    draw_disk( rctx, rstate );
    udpate_state( rstate );    
}
